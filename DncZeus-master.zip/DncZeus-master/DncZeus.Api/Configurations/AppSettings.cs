﻿namespace DncZeus.Api.Configurations
{
    /// <summary>
    /// 程序配置选项
    /// </summary>
    public class AppSettings
    {
        /// <summary>
        /// 是否是体验版
        /// </summary>
        public bool IsTrialVersion { get; set; }
    }
}
