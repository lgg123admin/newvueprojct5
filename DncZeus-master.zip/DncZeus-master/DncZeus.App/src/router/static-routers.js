// 不需要授权的路由名称
let staticRouters = ["home", "message_page", "error_store_page", "error_logger_page", "argu", "params", "query", "error_401", "error_500", "error_404","join","join_page"]
export default staticRouters;
