import Cropper from './index.vue'
export default Cropper
