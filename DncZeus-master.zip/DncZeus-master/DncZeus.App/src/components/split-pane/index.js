import Split from './split.vue'
export default Split
