# FastNet.Framework
It is a framework of .net core to help developers develop quickly
常用的.net core开发组件，助你有效的快速开发
FastNet.Framework.Consul-服务发现consul

FastNet.Framework.CSRedis-CsRedis组件封装

FastNet.Framework.Redis-StackExchangeRedis组件封装

FastNet.Framework.Dapper-基于Dapper的ORM框架

FastNet.Framework.JwtAuthorize-Jwt封装

FastNet.Framework.Mongo-mongodb的MongoDB.Driver组件封培训

FastNet.Framework.NetCrawler-封装的爬虫框架（多线程）

FastNet.Framework.Npoi-导入导出

FastNet.Framework.RabbitMQ-RabbitMQ通用组件封装
