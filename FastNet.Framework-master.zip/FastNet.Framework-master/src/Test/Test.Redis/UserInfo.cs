﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test.Redis
{
    public class UserInfo
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
    }
}
