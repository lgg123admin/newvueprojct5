﻿using FastNet.Framework.RabbitMQ;
using System;
using System.Collections.Generic;
using System.Text;

namespace Test.RabbitMq.Consumer
{
    public interface ITestHandler : IMqConsumerHandler
    {
    }
}
