﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test.RabbitMq.Publisher
{
    public class TestNotification
    {
        public string UserID { get; set; }
    }
}
