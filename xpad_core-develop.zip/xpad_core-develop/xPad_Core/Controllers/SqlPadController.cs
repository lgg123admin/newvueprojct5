﻿using System;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using xPad_Core.Dal.IDal;
using xPad_Core.Helper;
using xPad_Core.Model;
using xPad_Core.Model.MyModel;

namespace xPad_Core.Controllers
{
    [EnableCors("AllowSameDomain")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SqlPadController : ControllerBase
    {
        public SqlPadController(ISqlPadDal sqlPadDal)
        {
            SqlPadDal = sqlPadDal;
        }

        private ISqlPadDal SqlPadDal { get; }

        /// <summary>
        ///     获取数据
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult<object> GetData(JtDbQueryModel queryModel)
        {
            int pageIndex = queryModel.PageIndex;
            int pageSize = queryModel.PageSize;

            var resModel = new ResultModel
            {
                PageIndex = pageIndex,
                PageSize = pageSize
            };

            try
            {
                Log4Helper.Info("查询参数: /r/n" + JsonConvert.SerializeObject(queryModel));
                var nameList = ModelHelper.GetPropertiesName(new JtDb());
                
                var dataList = SqlPadDal.GetData(queryModel, pageIndex, pageSize,out int dataCount);

                // var dataCount = SqlPadDal.GetDataCount();
                // var pageCount = (dataCount + pageSize - 1) / pageSize;


                resModel.NameRes = JsonConvert.SerializeObject(nameList);

                resModel.DataRes = JsonConvert.SerializeObject(dataList);

                resModel.PageIndex = pageIndex;

                resModel.PageSize = pageSize;

                resModel.DataCount =  dataCount;

                resModel.IsSuccess = true;

                return resModel;
            }
            catch (Exception e)
            {
                Log4Helper.Error("查询条件 :" + JsonConvert.SerializeObject(queryModel) + "/r/n" + e.Message);

                resModel.IsSuccess = false;
                resModel.ErrorMessage = e.Message;
                return resModel;
            }
        }

        /// <summary>
        /// 获取所有数据库名称
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult<object> GetAllDataBaseName()
        {
            try
            {
                return SqlPadDal.GetAllDataBaseName();

            }
            catch (Exception e)
            {

                Log4Helper.Error(e.Message);
                return "";
            }
          
        }
        /// <summary>
        /// 获取所有"表名"
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult<object> GetAllDataTableName()
        {
          
            try
            {
                return SqlPadDal.GetAllDataTableName();

            }
            catch (Exception e)
            {
                Log4Helper.Error(e.Message);
                return "";
            }
        }
        /// <summary>
        /// 获取所有"列名"
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult<object> GetAllDataColumnName()
        {
            try
            {
                return SqlPadDal.GetAllDataColumnName();

            }
            catch (Exception e)
            {

                Log4Helper.Error(e.Message);
                return "";
            } 
            
        }
        
    }
}