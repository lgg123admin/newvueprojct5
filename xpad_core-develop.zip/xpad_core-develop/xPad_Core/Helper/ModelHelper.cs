using System.Collections.Generic;
using System.Reflection;

namespace xPad_Core.Helper
{
    /// <summary>
    ///     实体类 helper
    /// </summary>
    public class ModelHelper
    {
        /// <summary>
        ///     获取 实体类的 名称和值
        /// </summary>
        /// <param name="t">名称</param>
        /// <typeparam name="T">类型</typeparam>
        /// <returns>Dictionary</returns>
        public static Dictionary<string, string> GetProperties<T>(T t)
        {
            var ret = new Dictionary<string, string>();

            if (t == null) return null;

            var properties = t.GetType()
                .GetProperties(BindingFlags.Instance | BindingFlags.Public);

            if (properties.Length <= 0) return null;

            foreach (var item in properties)
            {
                var name = item.Name; //实体类字段名称
                var value = item.GetValue(t, null).ToString(); //该字段的值

                if (item.PropertyType.IsValueType || item.PropertyType.Name.StartsWith("String"))
                    ret.Add(name, value); //在此可转换value的类型
            }

            return ret;
        }

        /// <summary>
        ///     获取 实体类的 属性名
        /// </summary>
        /// <param name="t">名称</param>
        /// <typeparam name="T">类型</typeparam>
        /// <returns>字符串集合</returns>
        public static List<string> GetPropertiesName<T>(T t)
        {
            var ret = new List<string>();

            if (t == null) return null;

            var properties = t.GetType()
                .GetProperties(BindingFlags.Instance | BindingFlags.Public);

            if (properties.Length <= 0) return null;

            foreach (var item in properties)
            {
                var name = item.Name; //实体类字段名称

                if (item.PropertyType.IsValueType || item.PropertyType.Name.StartsWith("String"))
                    ret.Add(name); //在此可转换value的类型
            }

            return ret;
        }
    }
}