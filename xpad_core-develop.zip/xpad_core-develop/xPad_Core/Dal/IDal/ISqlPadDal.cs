﻿using System.Collections.Generic;
using xPad_Core.Model;

namespace xPad_Core.Dal.IDal
{
    public interface ISqlPadDal
    {
        /// <summary>
        ///     获取数据
        /// </summary>
        /// <param name="model">多条件查询model</param>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">每页显示条数</param>
        /// <param name="dataCount">根据条件查询出的数据量</param>
        /// <returns>json数据</returns>
        List<JtDb> GetData(JtDb model, int pageIndex, int pageSize,out int dataCount);
        
        /// <summary>
        ///     获取总数
        /// </summary>
        /// <returns>int</returns>
        int GetDataCount();

        /// <summary>
        /// 获取所有"数据库名称"
        /// </summary>
        /// <returns></returns>
        List<string> GetAllDataBaseName();

        /// <summary>
        /// 获取所有"表名"
        /// </summary>
        /// <returns></returns>
        List<string> GetAllDataTableName();
        
        /// <summary>
        /// 获取所有"列名"
        /// </summary>
        /// <returns></returns>
        List<string> GetAllDataColumnName();
    }
}