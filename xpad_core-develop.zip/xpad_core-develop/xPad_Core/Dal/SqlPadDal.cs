﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Newtonsoft.Json;
using xPad_Core.Dal.IDal;
using xPad_Core.DBContext;
using xPad_Core.Helper;
using xPad_Core.Model;

namespace xPad_Core.Dal
{
    /// <summary>
    ///     SqlPad数据访问
    /// </summary>
    public class SqlPadDal : ISqlPadDal
    {
        /// <summary>
        ///     获取数据
        /// </summary>
        public SqlPadDal(MyDBInfoContext service)
        {
            Service = service;
        }

        /// <summary>
        ///     获取数据
        /// </summary>
        private MyDBInfoContext Service { get; }

        /// <summary>
        ///     获取数据
        /// </summary>
        /// <param name="model">多条件查询model</param>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">每页显示条数</param>
        /// <param name="dataCount">根据条件查询出的数据量</param>
        /// <returns>json数据</returns>
        public List<JtDb> GetData(JtDb model, int pageIndex, int pageSize, out int dataCount)
        {
            var resData = string.Empty;
            try
            {
                #region 拼接条件

                Expression<Func<JtDb, bool>> expWhere = QueryAssembly.True<JtDb>();

                if (model.序号 > 0) expWhere = expWhere.And(x => x.序号 == model.序号);

                if (!string.IsNullOrEmpty(model.数据库名称)) expWhere = expWhere.And(x => x.数据库名称.Contains(model.数据库名称));

                if (!string.IsNullOrEmpty(model.表名)) expWhere = expWhere.And(x => x.表名.Contains(model.表名));

                if (!string.IsNullOrEmpty(model.列说明)) expWhere = expWhere.And(x => x.列说明.Contains(model.列说明));

                if (!string.IsNullOrEmpty(model.主键)) expWhere = expWhere.And(x => x.主键.Contains(model.主键));

                if (!string.IsNullOrEmpty(model.列名)) expWhere = expWhere.And(x => x.列名.Contains(model.列名));

                if (!string.IsNullOrEmpty(model.标识)) expWhere = expWhere.And(x => x.标识.Contains(model.标识));

                if (!string.IsNullOrEmpty(model.长度)) expWhere = expWhere.And(x => x.长度.Contains(model.长度));

                if (!string.IsNullOrEmpty(model.允许空)) expWhere = expWhere.And(x => x.允许空.Contains(model.允许空));

                if (!string.IsNullOrEmpty(model.默认值)) expWhere = expWhere.And(x => x.默认值.Contains(model.默认值));

                if (!string.IsNullOrEmpty(model.小数位数)) expWhere = expWhere.And(x => x.小数位数.Contains(model.小数位数));

                if (!string.IsNullOrEmpty(model.数据类型)) expWhere = expWhere.And(x => x.数据类型.Contains(model.数据类型));

                #endregion


                //查询数据
                var list = Service.JtDb
                    .Where(expWhere);

                dataCount = list.Count();

                var resList = list
                    .Skip(pageSize * (pageIndex - 1))
                    .Take(pageSize)
                    .ToList();
                return resList;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw e;
            }

            return new List<JtDb>();
        }

        /// <summary>
        ///     查询总数
        /// </summary>
        /// <returns>数量</returns>
        public int GetDataCount()
        {
            var count = Service.JtDb.Count();
            return count;
        }

        /// <summary>
        /// 获取所有"数据库名称"
        /// </summary>
        /// <returns></returns>
        public List<string> GetAllDataBaseName()
        {
            var resData = Service.JtDb.GroupBy(item => item.数据库名称).Select(item => item.Key).ToList();

            return resData;
        }

        public List<string> GetAllDataTableName()
        {
            var resData = Service.JtDb.GroupBy(item => item.表名).Select(item => item.Key).ToList();

            return resData;
        }

        public List<string> GetAllDataColumnName()
        {
            var resData = Service.JtDb.GroupBy(item => item.列名).Select(item => item.Key).ToList();

            return resData;
        }
    }
}