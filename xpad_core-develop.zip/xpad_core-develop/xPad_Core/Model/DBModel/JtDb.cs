﻿namespace xPad_Core.Model
{
    public class JtDb
    {
        public int 序号 { get; set; }
        public string 数据库名称 { get; set; }
        public string 表名 { get; set; }
        public string 列名 { get; set; }
        public string 列说明 { get; set; }
        public string 数据类型 { get; set; }
        public string 长度 { get; set; }
        public string 小数位数 { get; set; }
        public string 标识 { get; set; }
        public string 主键 { get; set; }
        public string 允许空 { get; set; }
        public string 默认值 { get; set; }

       
    }
}