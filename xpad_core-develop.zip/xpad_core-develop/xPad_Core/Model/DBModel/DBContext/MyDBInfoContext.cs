﻿using Microsoft.EntityFrameworkCore;
using xPad_Core.Model;

namespace xPad_Core.DBContext
{
    public class MyDBInfoContext : DbContext
    {
        public MyDBInfoContext()
        {
        }


        public MyDBInfoContext(DbContextOptions<MyDBInfoContext> options)
            : base(options)
        {
        }

        public virtual DbSet<JtDb> JtDb { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.1-servicing-10028");

            modelBuilder.Entity<JtDb>(entity =>
            {
                entity.HasKey(e => e.序号);

                entity.ToTable("JT_DB");

                entity.Property(e => e.序号).ValueGeneratedNever();
            });
        }
    }
}