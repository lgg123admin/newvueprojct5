namespace xPad_Core.Model.MyModel
{
    public class ResultModel
    {
        /// <summary>
        /// 列名
        /// </summary>
        public string NameRes { get; set; }
        
        /// <summary>
        /// 数据
        /// </summary>
        public string DataRes { get; set; }
        
        /// <summary>
        /// 当前页
        /// </summary>
        public int PageIndex { get; set; }
        
        /// <summary>
        /// 每页数量
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// 数据总数
        /// </summary>
        public int DataCount { get; set; } = 0;
        
        /// <summary>
        /// 是否成功
        /// </summary>
        public bool IsSuccess { get; set; } = false;
        
        /// <summary>
        /// 异常信息
        /// </summary>
        public string ErrorMessage { get; set; }
    }
}