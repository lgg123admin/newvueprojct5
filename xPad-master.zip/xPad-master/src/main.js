
// vue组件
import Vue from 'vue'
import App from './App'
// vue路由
import router from './router'

// 接口访问(同jq的 ajax)
import axios from 'axios'
import qs from 'qs'
Vue.prototype.$axios = axios    //全局注册，使用方法为:this.$axios
Vue.prototype.qs = qs           //全局注册，使用方法为:this.qs

// Bootstrap_Vue
import BootstrapVue from 'bootstrap-vue'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
Vue.use(BootstrapVue);

// layer_Vue
import layer from 'vue-layer'
Vue.prototype.$layer = layer(Vue, {
  msgtime: 3,
});

// api 接口地址
Vue.config.productionTip = false;
Vue.prototype.baseURL = process.env.API_ROOT;
Vue.prototype.baseURL2 = process.env.API_ROOT2;

// iview  UI库导入
import iView from 'iview';
import 'iview/dist/styles/iview.css';
Vue.use(iView);

// vue路由跳转前
router.beforeEach((to, from, next) => {
  iView.LoadingBar.start();//iview 加载进度条开始
  next();
});

// vue路由跳转后
router.afterEach(route => {
  iView.LoadingBar.finish();//iview 加载进度条结束
});

new Vue({
  el: '#app',
  router,
  components: {
    App
  },
  template: '<App/>'
})





