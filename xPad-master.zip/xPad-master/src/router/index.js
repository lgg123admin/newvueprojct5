import Vue from 'vue'
import Router from 'vue-router'

// 模板页
import Layout from '@/components/layout/Layout.vue'

// 欢迎页
import Hello from '@/components/layout/Hello.vue'

// 数据库字段查询
import DatabaseFieldQuery from '@/components/DatabaseFieldQuery.vue'

// 字符串处理
import StringOperation from '@/components/StringOperation.vue'

Vue.use(Router)

export default new Router({

  routes: [
    {
      path: '',
      name: 'layout',
      component: Layout,
      children: [
        {
          path: '',
          name: 'Hello',
          meta: {
            title: '首页'
          },
          component: Hello
        },
        {
          path: '/DatabaseFieldQuery',
          name: 'DatabaseFieldQuery',
          meta: {
            title: '数据库字段查询'
          },
          component: DatabaseFieldQuery
        },
        {
          path: '/StringOperation',
          name: 'StringOperation',
          meta: {
            title: '字符串处理'
          },
          component: StringOperation
        }

      ]
    }
  ]
})
