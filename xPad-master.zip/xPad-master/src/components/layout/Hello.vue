<!--  -->
<template>
  <!-- 提示块 -->
  <Alert show-icon closable>
    <span style="color:green">友情提示:</span>
    <template slot="desc">
      <span style="color:green;font-size:15px" v-html="browserInfo"></span>
    </template>
  </Alert>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      browserInfo: ""
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    //返回 浏览器简略信息
    getSimpleBrowserInfo: function() {
      var msg = navigator.userAgent
        .toLowerCase()
        .match(/\s([a-z]+)[\/]([\d.]+)/g);

      return msg
        .join(",")
        .replace(/\//g, "     版本号: ")
        .replace(/,/g, "</br>");
    },

    //返回浏览器信息 结果
    getResultBrowser: function(getVersion) {
      //注意关键字大小写
      var ua_str = navigator.userAgent.toLowerCase(),
        ie_Tridents,
        trident,
        match_str,
        ie_aer_rv,
        browser_chi_Type;

      //判断IE 浏览器
      if ("ActiveXObject" in self) {
        //IE 的版本.
        ie_aer_rv = (match_str = ua_str.match(/msie ([\d.]+)/))
          ? match_str[1]
          : (match_str = ua_str.match(/rv:([\d.]+)/))
          ? match_str[1]
          : 0;

        // ie: 指出当前IE浏览器的真正版本。
        ie_Tridents = {
          "trident/7.0": 11,
          "trident/6.0": 10,
          "trident/5.0": 9,
          "trident/4.0": 8
        };
        //匹配 ie8, ie11, edge
        trident = (match_str = ua_str.match(/(trident\/[\d.]+|edge\/[\d.]+)/))
          ? match_str[1]
          : undefined;
        browser_chi_Type =
          (ie_Tridents[trident] || ie_aer_rv) > 0 ? "ie" : undefined;
      } else {
        //判断 windows edge 浏览器
        // match_str[1]: 返回浏览器及版本号,如: "edge/13.10586"
        // match_str[1]: 返回版本号,如: "edge"

        //若要返回 "edge" 请把下行的 "ie" 换成 "edge"。 注意引号及冒号是英文状态下输入的
        browser_chi_Type = (match_str = ua_str.match(/edge\/([\d.]+)/))
          ? "edge"
          : //判断firefox 浏览器
          (match_str = ua_str.match(/firefox\/([\d.]+)/))
          ? "firefox"
          : //判断chrome 浏览器
          (match_str = ua_str.match(/chrome\/([\d.]+)/))
          ? "chrome"
          : //判断opera 浏览器
          (match_str = ua_str.match(/opera.([\d.]+)/))
          ? "opera"
          : //判断safari 浏览器
          (match_str = ua_str.match(/version\/([\d.]+).*safari/))
          ? "safari"
          : undefined;
      }

      //返回浏览器类型和版本号
      var verNum, verStr;
      verNum =
        trident && ie_Tridents[trident] ? ie_Tridents[trident] : match_str[1];

      verStr =
        getVersion != undefined
          ? browser_chi_Type + "/" + verNum
          : browser_chi_Type;
      return verStr;
    }
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {
    var msgs = [
      "<span style='color:red'>完整信息:</span></br>" +
        navigator.userAgent.toLowerCase(),
      "<span style='color:red'>简略信息:</span></br>" +
        this.getSimpleBrowserInfo(),
      "<span style='color:red'>结果:</span></br>" +
        "<span style='color:blue'>" +
        this.getResultBrowser(1) +
        "</span>"
    ];
    this.browserInfo = msgs.join("</br>");
  },
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {} //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>

<style scoped>
</style>
