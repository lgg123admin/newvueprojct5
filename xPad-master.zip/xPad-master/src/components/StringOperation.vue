<template>
  <div class="demo-split">
    <Split v-model="split1">
      <div slot="left" class="demo-split-pane">
        <Input
          @on-blur="leftFocus"
          v-model="value6"
          type="textarea"
          :rows="inputRows"
          placeholder="Enter something..."
        />
      </div>
      <div slot="right" class="demo-split-pane" style="padding-left:14px">
        <Input
          @on-blur="rightFocus"
          v-model="value6"
          type="textarea"
          :rows="inputRows"
          placeholder="Enter something..."
        />
      </div>
    </Split>
  </div>
</template>
<script>
export default {
  data() {
    return {
      // split间距
      split1: 0.5,
      // 文本域高
      inputRows: 37,
      value6: ""
    };
  },
  methods: {
    // 下划线转换驼峰
    toHump: function(name) {
      return name.replace(/\_(\w)/g, function(all, letter) {
        return letter.toUpperCase();
      });
    },
    // 驼峰转换下划线
    toLine: function(name) {
      return name.replace(/([A-Z])/g, "_$1").toLowerCase();
    },
    //左边聚焦
    leftFocus: function() {},
    //右边聚焦
    rightFocus: function() {}
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {} //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style scoped>
.demo-split {
  height: 810px;
  border: 1px solid #dcdee2;
}
.demo-split-pane {
  padding: 10px;
}
</style>



