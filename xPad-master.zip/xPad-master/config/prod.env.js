'use strict'
//线上环境配置
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://10.10.207.20:81/api"'

}
