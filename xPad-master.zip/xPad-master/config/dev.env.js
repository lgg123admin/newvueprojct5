'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

//开发环境配置
module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  API_ROOT2: '"http://localhost:9091/api"',
  API_ROOT: '"http://10.10.207.20:81/api"'
})
